#!/usr/bin/env python

import sys
import cv2
import rospy
import time
import numpy as np
import math

from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from std_msgs.msg import String

from pickplace.msg import pickPub
from pickplace.msg import pickSub

num = 0
dep_bridge = CvBridge()
desk = 1050
obj_inf = rospy.Publisher("/pickPubMsg", pickPub, queue_size=1)
NEED = 0
SubCountLast = 0
start = 0
flag_count = 0

def setNEED(msg):
    global NEED
    global SubCountLast
    global start
    if msg.count == 0:
        start = 0
        SubCountLast = msg.count
    if msg.count != SubCountLast:
        NEED=1
        SubCountLast = msg.count
    


def rgb_callback(data1):
    global num
    rgb_bridge = CvBridge()
    rgb_image = rgb_bridge.imgmsg_to_cv2(data1, "bgr8")
    rgb_image = rgb_image[100:385,50:620]
    if num%10==0:
        cv2.imwrite('/home/robot/Desktop/g/rgb.png',rgb_image)
    num = num + 1

def depth_seg(img):
    global NEED
    global SubCountLast
    global start
    global flag_count

    flag_count = flag_count + 1
    if flag_count<40 :#40
        return
    else:
        flag_count = 0


    start = 1#lxc
    NEED = 1 #lxc
    #if start ==0:
        #print("\n\n")
        #ch = raw_input("input 's' to start!")
        #if ch == 's':
        #    start = 1
        #    NEED = 1

    if NEED==0 or start==0:
        return
    depth_img = dep_bridge.imgmsg_to_cv2(img,"passthrough")
    #cv2.imwrite('/home/robot/Desktop/depth.png',depth_img)

    depth_image = depth_img[100:385,50:620]
    depth_image.flags.writeable = True
    #depth_mean = np.mean(depth_image[depth_image!=0])
    #dep_min = depth_image[np.unravel_index(np.argmin(depth_image), depth_image.shape)]
    #print(depth_mean, dep_min)
    #return
    depth_image[depth_image>=desk]=0
    depth_image[depth_image==0]=1500
    pos = np.unravel_index(np.argmin(depth_image), depth_image.shape)
    key_point = depth_image[pos]
    if abs(key_point-desk)<7 or key_point==1500:
        print("nothing!!!")
        start = 0
        #obj_inf.publish("F,0,0,0,0,0")
        return

    p = 0.0
    grasp_x=0.0
    grasp_y=0.0
    grasp_z=0.0
    grasp_l=0.0
    grasp_th=0.0
    ell=()

    for cut in range(5,30,1):
        cutdepth = key_point + cut
        tmpdepth = depth_image.copy()
        tmpdepth[tmpdepth<cutdepth]=0
        tmpdepth[tmpdepth>=cutdepth]=65535
        tmpdepth = tmpdepth.astype(np.uint8)

        ret, thresh = cv2.threshold(tmpdepth, 125, 255, cv2.THRESH_BINARY)
        image, contours, hierarchy = cv2.findContours(thresh, 2, 1)
        if len(contours)<=1:
            continue
        
        #ttt = np.zeros((335,610,3),np.uint8)

        for cnt in contours:
            huil = cv2.convexHull(cnt)
            cnt_area = cv2.contourArea(cnt)
            huil_area = cv2.contourArea(huil)
        
            if cnt_area>=100000:
                continue
            if huil_area>=100000:
                continue
            if cnt_area<200:
                continue
            if huil_area<200:
                continue
            if cnt_area/huil_area<0.85:
                continue
            if cv2.pointPolygonTest(cnt, (pos[1],pos[0]), False)!=1:
                continue

            ell=cv2.fitEllipse(cnt)
            
            if len(ell)!=3:
                continue

            if p<cnt_area/huil_area:
                p=cnt_area/huil_area
                grasp_x=ell[0][1]
                grasp_y=ell[0][0]
                uintx = int(math.floor(grasp_x))
                uinty = int(math.floor(grasp_y))
                grasp_z = depth_image[uintx][uinty]
                grasp_l = ell[1][0]*2
                grasp_th = ell[2]
                
                #print(grasp_x, grasp_y, grasp_z, grasp_l, grasp_th)
            #ttt = cv2.drawContours(ttt, cnt, -1, (0,255,0), 2)
            #for i in range(len(huil)):
            #    cv2.line(ttt, tuple(huil[i][0]), tuple(huil[(i+1)%len(huil)][0]), (0,0,255), 2)
        #cv2.imwrite('/home/robot/Desktop/g/'+str(cut)+'.png', ttt)
    
    img = cv2.imread('/home/robot/Desktop/g/rgb.png',3)
    if len(ell)!=3:
        print("need Calibration!")
        #start = 0
        return
    img = cv2.ellipse(img, ell, (0,0,255), 2)
    cv2.imshow('ell_img', img)
    cv2.waitKey(1)
    cv2.imwrite('/home/robot/Desktop/g/ell.png', img)

    pickPubMsg = pickPub()
    pickPubMsg.count = SubCountLast
    pickPubMsg.grasp_x = uinty
    pickPubMsg.grasp_y = uintx
    pickPubMsg.grasp_z = grasp_z
    pickPubMsg.grasp_l = grasp_l
    pickPubMsg.grasp_th = grasp_th
    obj_inf.publish(pickPubMsg)
    print(uinty, uintx, grasp_z, grasp_l, grasp_th)
    
    NEED=0

if __name__ == '__main__':

    rospy.init_node('xtionpro')
    depth_sub = rospy.Subscriber("/camera/depth_registered/image",Image,depth_seg)
    image_sub = rospy.Subscriber("/camera/rgb/image_raw",Image,rgb_callback,queue_size=1)
    needDetec = rospy.Subscriber("/pickSubMsg", pickSub, setNEED,queue_size=1)
    
    rospy.spin()
