#include <ros/ros.h>
#include <std_msgs/String.h>

//#include <mypkg/threeLocation.h>
#include <robotiq_85_msgs/threeLocation.h>
#include <object_detection/twoLocation.h>
#include <pickplace/pickPub.h>
#include <pickplace/pickSub.h>

#include <fstream>
#include <iostream>
#include <string>
#include <stdlib.h> 
#include <memory.h>
#include <stdio.h>
#include <unistd.h>
#include <opencv2/opencv.hpp>
#include <math.h>
#include <time.h> 

using namespace cv;
using namespace std;
using namespace ros;

Publisher location_pub;
Subscriber two_dim_sub;
Subscriber PickPlace_sub;
robotiq_85_msgs::threeLocation three_location;

double im_robot(double * centre, double * coordinate);
void poseTrans(const object_detection::twoLocation& two_dim_msg);

void poseTrans_PickPlace(const pickplace::pickPub& pickPubMsg);
double im_robot_PickPlace(double * centre, double * coordinate);

int countLast = 0;

int main (int argc, char ** argv) {

	init(argc, argv, "trans_location");
	NodeHandle nh;
	//two_dim_sub = nh.subscribe("/two_dim", 1, &poseTrans);
	PickPlace_sub = nh.subscribe("/pickPubMsg", 1, &poseTrans_PickPlace);
	location_pub = nh.advertise<robotiq_85_msgs::threeLocation>("/three_dim",1);

	sleep(0.5);
	spin();
}


void poseTrans_PickPlace(const pickplace::pickPub& pickPubMsg) {
	//double dur;
	//clock_t start, end;
	//start = clock();
	cout << "poseTrans_PickPlace()" << endl;
	//cout << "pickPubMsg.count:"<< pickPubMsg.count<< " countLast:"<< countLast << endl;　
	cout<<"count:"<<pickPubMsg.count<<"countLast:"<<countLast<<endl;
	if(pickPubMsg.count == countLast)
	{
		return;
	}
	else
	{
		countLast = pickPubMsg.count;
	}


	double centre[3] = { 0, 0, 0 };
	double coordinate[3] = { 0, 0, 0 };
	int angle;
	int put_num;
	centre[0] = pickPubMsg.grasp_x;
	centre[1] = pickPubMsg.grasp_y;
	centre[2] = pickPubMsg.grasp_z;
	three_location.angle = pickPubMsg.grasp_th;
	three_location.put_num = 1;
	im_robot_PickPlace(centre, coordinate);
	double radius = sqrt(pow(coordinate[0], 2) + pow(coordinate[1], 2)) * 1000;
	//cout << three_location.x << " " << three_location.y << " " << three_location.z << " " << three_location.angle << " " << three_location.put_num << endl;
	cout << "coordinate[2]:"<<coordinate[2]<<"radius:"<<radius<<endl;

	// if(coordinate[2] < 400 && radius > 300 && radius < 860) {
	if(coordinate[2] < 500 && radius > 220 && radius < 550) {
		three_location.x = coordinate[0];
		three_location.y = coordinate[1];
		three_location.z = coordinate[2];
		location_pub.publish(three_location);
		cout << three_location.x << " " << three_location.y << " " << three_location.z << " " << three_location.angle << " " << three_location.put_num << endl;
		cout <<"In reach"<<endl;
	}
	else
	{
		cout <<"Out of reach"<<endl;
		three_location.put_num = 100;
		location_pub.publish(three_location);

	}
	

	//end = clock();
	//dur = (double)(end - start);
	//printf("Use Time:%f\n",(dur/CLOCKS_PER_SEC));
	//ROS_INFO_STREAM(" YES");
}


double im_robot_PickPlace(double * centre, double * coordinate) {

	//double dur;
	//clock_t start, end;
	//start = clock();

	double kx = 523.368347, ky = 526.698364, u0 = 305.245566, v0 = 253.888669;
	double M_in[9] = { kx, 0, u0, 0, ky, v0, 0, 0, 1 };
	double M_ou[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };


	double centre1[3] = { centre[0], centre[1], 1 };
	double centre2[3] = { 0, 0, 0 };
	double centre3[4] = { 0, 0, 0, 1 };
	//double Tm[16] = { -0.7068, 0.7073, 0.0133, -622.6721, 0.7073, 0.7069, -0.0025, -346.7504, -0.0112, 0.0076, -0.9979, 1183.7, 0, 0, 0, 1.0000 };
	double Tm[16] = { 0.9996 * 1.03, 0.0184 * 1.03, -0.0202 * 0.9, -29.7, 0.0183, -0.9998 * 1.1, -0.0013 * 1.03, -655.9, -0.0203, 0.0009, -0.9998, 1132.7, 0, 0, 0, 1.0000 };
	double S[3] = {1.004, 1, 1};//0.8291;{1.004, 0.990, 1}
	double T[4] = { 0, 0, 0, 0 };

	// Mat depth = imread("/home/robot/dxd/ros_ws/results/depth/depth.png", 2);
	// if(depth.empty() )
	// {
	// 	ROS_ERROR("Read the picture failed!");
	// 	return -1;
	// }
	// double zc = depth.at<unsigned short>(centre[1], centre[0]);
	double zc = centre[2];
	cout << zc << endl;
	if (zc <= 0) {
		zc = 962;
		cout << zc << endl;
	}

	CvMat M1 = cvMat(3, 3, CV_64FC1, M_in);
	CvMat M2 = cvMat(3, 3, CV_64FC1, M_ou);
	CvMat C1 = cvMat(3, 1, CV_64FC1, centre1);
	CvMat C2 = cvMat(3, 1, CV_64FC1, centre2);

	cvInvert(&M1, &M2);
	cvMatMul(&M2, &C1, &C2);

	centre3[0] = centre2[0] * zc;//0.025
	centre3[1] = centre2[1] * zc;//0.02;
	centre3[2] = centre2[2] * zc;

	for (int i = 0; i < 4; i++) {
		T[i] = S[i] * Tm[4 * i] * centre3[0] + S[i] * Tm[4 * i + 1] * centre3[1] +
			S[i] * Tm[4 * i + 2] * centre3[2] + Tm[4 * i + 3] * centre3[3];
	}

	coordinate[0] = T[0] / 1000 + 0.004;
	coordinate[1] = T[1] / 1000 + 0.013;
	coordinate[2] = T[2] / 1000 * 0.55;

	cout << coordinate[2] << endl;
	if (coordinate[2] < 0.035) {
		coordinate[2] = 0.035;
	}

	//end = clock();
	//dur = (double)(end - start);
	//printf("Use Time:%f\n",(dur/CLOCKS_PER_SEC));

	return coordinate[3];
}



void poseTrans(const object_detection::twoLocation& two_dim_msg) {
	//double dur;
	//clock_t start, end;
	//start = clock();

	double centre[2] = { 0, 0 };
	double coordinate[3] = { 0, 0, 0 };
	int angle;
	int put_num;
	centre[0] = two_dim_msg.x;
	centre[1] = two_dim_msg.y;
	three_location.angle = two_dim_msg.angle;
	three_location.put_num = two_dim_msg.put_num;
	im_robot(centre, coordinate);
	double radius = sqrt(pow(coordinate[0], 2) + pow(coordinate[1], 2)) * 1000;
	if(coordinate[2] < 400 && radius > 300 && radius < 860) {
		three_location.x = coordinate[0];
		three_location.y = coordinate[1];
		three_location.z = coordinate[2];
		location_pub.publish(three_location);
		cout << three_location.x << " " << three_location.y << " " << three_location.z << " " << three_location.angle << " " << three_location.put_num << endl;
	}

	//end = clock();
	//dur = (double)(end - start);
	//printf("Use Time:%f\n",(dur/CLOCKS_PER_SEC));
	//ROS_INFO_STREAM(" YES");
}

double im_robot(double * centre, double * coordinate) {

	//double dur;
	//clock_t start, end;
	//start = clock();

	double kx = 523.368347, ky = 526.698364, u0 = 305.245566, v0 = 253.888669;
	double M_in[9] = { kx, 0, u0, 0, ky, v0, 0, 0, 1 };
	double M_ou[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };


	double centre1[3] = { centre[0], centre[1], 1 };
	double centre2[3] = { 0, 0, 0 };
	double centre3[4] = { 0, 0, 0, 1 };
	//double Tm[16] = { -0.7068, 0.7073, 0.0133, -622.6721, 0.7073, 0.7069, -0.0025, -346.7504, -0.0112, 0.0076, -0.9979, 1183.7, 0, 0, 0, 1.0000 };
	double Tm[16] = { 0.9996 * 1.03, 0.0184 * 1.03, -0.0202 * 0.9, -29.7, 0.0183, -0.9998 * 1.1, -0.0013 * 1.03, -655.9, -0.0203, 0.0009, -0.9998, 1132.7, 0, 0, 0, 1.0000 };
	double S[3] = {1.004, 1, 1};//0.8291;{1.004, 0.990, 1}
	double T[4] = { 0, 0, 0, 0 };

	Mat depth = imread("/home/robot/dxd/ros_ws/results/depth/depth.png", 2);
	if(depth.empty() )
	{
		ROS_ERROR("Read the picture failed!");
		return -1;
	}
	double zc = depth.at<unsigned short>(centre[1], centre[0]);
	cout << zc << endl;
	if (zc <= 0) {
		zc = 962;
		cout << zc << endl;
	}

	CvMat M1 = cvMat(3, 3, CV_64FC1, M_in);
	CvMat M2 = cvMat(3, 3, CV_64FC1, M_ou);
	CvMat C1 = cvMat(3, 1, CV_64FC1, centre1);
	CvMat C2 = cvMat(3, 1, CV_64FC1, centre2);

	cvInvert(&M1, &M2);
	cvMatMul(&M2, &C1, &C2);

	centre3[0] = centre2[0] * zc;//0.025
	centre3[1] = centre2[1] * zc;//0.02;
	centre3[2] = centre2[2] * zc;

	for (int i = 0; i < 4; i++) {
		T[i] = S[i] * Tm[4 * i] * centre3[0] + S[i] * Tm[4 * i + 1] * centre3[1] +
			S[i] * Tm[4 * i + 2] * centre3[2] + Tm[4 * i + 3] * centre3[3];
	}

	coordinate[0] = T[0] / 1000 + 0.004;
	coordinate[1] = T[1] / 1000 + 0.013;
	coordinate[2] = T[2] / 1000 * 0.55;

	cout << coordinate[2] << endl;
	if (coordinate[2] < 0.035) {
		coordinate[2] = 0.035;
	}

	//end = clock();
	//dur = (double)(end - start);
	//printf("Use Time:%f\n",(dur/CLOCKS_PER_SEC));

	return coordinate[3];
}

